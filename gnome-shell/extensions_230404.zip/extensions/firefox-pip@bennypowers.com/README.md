# gnome-shell-extension-firefox-pip

Makes Firefox's Picture-in-Picture windows always on top, automatically.
